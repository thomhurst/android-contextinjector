package com.tomlonghurst.contextinjector

import android.app.Activity
import android.content.Context
import java.util.*

object WeakReferenceMaps {
    val contexts = WeakHashMap<Any, Context>()
    val activities = WeakHashMap<Any, Activity>()
}
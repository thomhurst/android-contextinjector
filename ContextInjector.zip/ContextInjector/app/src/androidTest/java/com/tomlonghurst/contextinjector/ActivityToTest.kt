package com.tomlonghurst.contextinjector

import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.test.runner.AndroidJUnit4
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText

import kotlinx.android.synthetic.main.activity_test.*
import org.junit.Test
import org.junit.runner.RunWith
import java.lang.Exception
import java.lang.RuntimeException

@RunWith(AndroidJUnit4::class)
class ActivityTest {
    @Test
    fun testEvent() {
        val scenario = launch<MyActivity>()
    }
}

class ActivityToTest : AppCompatActivity() {

    private val editText by ActivityInjector(this) { activity ->  EditText(activity) }
    private val editText2 = EditText(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test)
        setSupportActionBar(toolbar)

        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }

        test()
    }

    private fun test() {
        doNotUseAppActivity()
        useAppActivityWithoutInitialising()
        useAppActivityWithInitialising()
    }

    fun doNotUseAppActivity() {
        // Context of the app under test.
        println("Bla")
    }

    fun useAppActivityWithoutInitialising() {
        // Context of the app under test.
        try {
            val text = editText.text
            throw Exception("Should not hit this - Won't be caught by catch as it is a high level exception")
        } catch (e: ContextNotFoundException) {
            println(e.message)
        }
    }

    fun useAppActivityWithInitialising() {
        // Context of the app under test.
        ContextInjector.injectContext(this)
        val text = editText.text.toString()
        if(text.isNotBlank()) throw Exception("")
    }

}

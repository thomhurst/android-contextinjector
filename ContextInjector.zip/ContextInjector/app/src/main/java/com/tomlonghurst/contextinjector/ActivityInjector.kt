package com.tomlonghurst.contextinjector

import android.app.Activity
import android.content.Context
import java.lang.RuntimeException
import kotlin.reflect.KProperty

class ActivityInjector<Return>(val thisClass: Activity, private val initializer: (activity: Activity) -> Return)
{

    operator fun getValue(thisRef:Any,property: KProperty<*>):Return = synchronized(WeakReferenceMaps.activities)
    {
        val context = WeakReferenceMaps.activities[thisClass] ?: throw ContextNotFoundException()
        return@synchronized initializer.invoke(context)
    }

}
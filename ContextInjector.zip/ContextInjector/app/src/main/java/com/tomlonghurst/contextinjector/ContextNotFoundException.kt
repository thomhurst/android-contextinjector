package com.tomlonghurst.contextinjector

class ContextNotFoundException : Throwable() {
    override val message: String?
        get() = "Context not found. Have you called ContextInjector.injectContext(...) ?"
}
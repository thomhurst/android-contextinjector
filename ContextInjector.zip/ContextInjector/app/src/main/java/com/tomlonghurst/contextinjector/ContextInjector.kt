package com.tomlonghurst.contextinjector

import android.app.Activity
import android.content.Context
import java.lang.RuntimeException
import kotlin.reflect.KProperty

class ContextInjector<Return>(private val thisClass: Context, private val initializer: (context: Context) -> Return)
{

    operator fun getValue(thisRef:Any,property: KProperty<*>):Return = synchronized(WeakReferenceMaps.activities) {
        synchronized(WeakReferenceMaps.contexts)
        {
            val context = WeakReferenceMaps.activities[thisClass] ?: WeakReferenceMaps.contexts[thisClass]
            ?: throw ContextNotFoundException()
            return initializer.invoke(context)
        }
    }

    companion object {
        fun injectContext(context: Context) {
            if(context is Activity) {
                WeakReferenceMaps.activities[context] = context
            } else {
                WeakReferenceMaps.contexts[context] = context
            }
        }
    }

}
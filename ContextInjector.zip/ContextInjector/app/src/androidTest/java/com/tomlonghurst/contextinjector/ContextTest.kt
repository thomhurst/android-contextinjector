package com.tomlonghurst.contextinjector

import android.support.test.InstrumentationRegistry
import android.support.test.runner.AndroidJUnit4
import android.widget.EditText
import org.junit.Assert
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4::class)
class ContextTest {

    private val editText by ContextInjector(InstrumentationRegistry.getContext()) { context ->  EditText(context) }

    @Test
    fun doNotUseAppContext() {
        // Context of the app under test.
        println("Bla")
    }

    @Test(expected = ContextNotFoundException::class)
    fun useAppContextWithoutInitialising() {
        // Context of the app under test.
        val text = editText.text
        Assert.assertEquals("", text)
    }

    @Test
    fun useAppContextWithInitialising() {
        // Context of the app under test.
        ContextInjector.injectContext(InstrumentationRegistry.getContext())
        val text = editText.text.toString()
        Assert.assertEquals("", text)
    }
}
